import { useState, useEffect } from 'react';
import Modal from '@/components/Modal';
import '../styles/navbar.css';
import '../styles/slider.css';
import '../styles/hero.css';
import '../styles/gallery.css';
import '../styles/footer.css';
import '../styles/floating-button.css';
import '../styles/modal.css';

export default function Home() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [currentVideoSlide, setCurrentVideoSlide] = useState(0);
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, action: string) => {
    e.preventDefault();
    if (action === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (action === 'catalogo') {
      scrollToSection('catalogo');
    } else if (action === 'que-puedes') {
      scrollToSection('juega-con-imaginacion');
    } else {
      setActiveModal(action);
    }
  };

  const banners = [
    {
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/banner-arepa-1-NarjrVYNBLxeGevxA8fXjh.webp',
      title: 'Arepas Recién Hechas',
      description: 'Disfruta de nuestras deliciosas arepas preparadas con ingredientes frescos y de la más alta calidad. Cada arepa es un viaje al corazón de la tradición venezolana.'
    },
    {
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/banner-arepa-2-GUJikf3Xhgfu5gtnxGD8jU.webp',
      title: 'Arepa con Carne y Queso',
      description: 'Una combinación perfecta de carne jugosa y queso derretido. Sabor que enamora en cada bocado, preparado con amor y dedicación.'
    },
    {
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/banner-arepa-3-deC7hB5t9ECYy4SHh7TCii.webp',
      title: 'Variedad de Sabores',
      description: 'Explora nuestro amplio catálogo de arepas con diferentes rellenos. Desde lo clásico hasta lo innovador, tenemos algo para todos los gustos.'
    }
  ];

  const products = [
    {
      image: '/manus-storage/arepa-queso_ad102b65.png',
      name: 'Arepa Rellena de Queso',
      description: 'Arepa con un queso cremoso que se estira en cada mordida y que te antoja con su olor',
      details: 'Nuestra arepa de queso es la más tradicional: hecha a base de maíz peto de alta calidad; con un queso derretido que obtiene una textura perfecta que ofrece una experiencia culinaria incomparable.'
    },
    {
      image: '/manus-storage/arepa-queso-bocadillo_473849da.png',
      name: 'Arepa Rellena de Queso y Bocadillo',
      description: 'Una arepa con un queso cremoso y un bocadillo delicioso que le da un toque dulce a la receta',
      details: 'Un bocadillo seleccionado que no es empalagoso mezclado con nuestra deliciosa arepa con queso. Una combinación colombiana que garantiza una ternura en cada bocado y el queso cremoso complementa perfectamente el sabor suave del bocadillo.'
    },
    {
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/arepa-queso-huevo-cqEZ3c5Z3D8m9zKmYmxYFN.webp',
      name: 'Arepa Rellena de Queso y Huevo',
      description: 'Huevo fresco con queso derretido, perfecta para el desayuno',
      details: 'Ideal para comenzar el día, esta arepa combina huevo fresco cocinado al punto con queso derretido. Una opción nutritiva y deliciosa para cualquier hora del día.'
    },
    {
      image: '/manus-storage/arepa-queso-jamon_e13aae09.png',
      name: 'Arepa Rellena de Queso y Jamón',
      description: 'Jamón de calidad premium con queso derretido',
      details: 'Utilizamos jamón de la más alta calidad, importado especialmente para mantener nuestro estándar de excelencia. Combinado con queso derretido, es una delicia para los paladares más exigentes.'
    },
    {
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/arepa-mora-leche-8DRSa2PFi4MfsrdQfXeVC2.webp',
      name: 'Arepa de Queso con Mora y Leche',
      description: 'Queso con salsa de mora y leche condensada, un postre delicioso',
      details: 'Nuestra arepa dulce es un postre único que combina queso fresco con una deliciosa salsa de mora casera y leche condensada. Una experiencia dulce y memorable.'
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % banners.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length);
  };

  const nextVideoSlide = () => {
    setCurrentVideoSlide((prev) => (prev + 1) % 2);
  };

  const prevVideoSlide = () => {
    setCurrentVideoSlide((prev) => (prev - 1 + 2) % 2);
  };

  useEffect(() => {
    const timer = setInterval(nextSlide, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="home">
      {/* Navbar */}
      <nav className="navbar">
        <div className="navbar-container">
          <div className="logo-container">
            <img 
              src="/manus-storage/logo-fabrica-arepas-ruiz-transparent_c56425a6.png" 
              alt="Fábrica de Arepas Ruiz" 
              className="logo"
            />
          </div>

          <div className="social-links">
            <a href="https://www.tiktok.com/@fabrica.de.arepas0" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="TikTok: fabrica.de.arepas0" title="TikTok: fabrica.de.arepas0">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.68v13.67a2.4 2.4 0 1 1-4.77-1.3A2.403 2.403 0 0 1 9.1 13.5v-3.72a8.05 8.05 0 0 0-5.78 2.47v4.6a6.45 6.45 0 1 0 12.14-4.53"/>
              </svg>
            </a>
            <a href="https://www.facebook.com/fabricadearepasruiz" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Facebook: Fábrica de Arepas Ruiz" title="Facebook: Fábrica de Arepas Ruiz">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
            </a>
            <a href="https://www.instagram.com/arepasruizoficial" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="Instagram: arepasruizoficial" title="Instagram: arepasruizoficial">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C8.74 0 8.333.015 7.053.072 5.775.132 4.905.333 4.117.6c-.79.263-1.473.557-2.115 1.2-.643.642-.937 1.325-1.2 2.115-.267.788-.468 1.658-.53 2.936C.06 8.333.05 8.74 0 12s.015 3.667.072 4.947c.06 1.277.261 2.148.53 2.936.263.79.557 1.473 1.2 2.115.642.643 1.325.937 2.115 1.2.788.268 1.658.468 2.936.53 1.28.06 1.687.072 4.947.072s3.667-.015 4.947-.072c1.277-.062 2.148-.262 2.936-.53.79-.263 1.473-.557 2.115-1.2.643-.642.937-1.325 1.2-2.115.268-.788.468-1.658.53-2.936.06-1.28.072-1.687.072-4.947s-.015-3.667-.072-4.947c-.06-1.277-.262-2.149-.53-2.936-.263-.79-.557-1.473-1.2-2.115-.642-.643-1.325-.937-2.115-1.2-.788-.268-1.658-.468-2.936-.53C15.667.06 15.26.05 12 0zm0 2.16c3.203 0 3.585.009 4.849.070 1.171.054 1.805.244 2.227.408.562.217.96.477 1.382.896.419.42.679.819.896 1.381.164.422.354 1.057.408 2.227.061 1.264.07 1.646.07 4.849s-.009 3.585-.07 4.849c-.054 1.171-.244 1.805-.408 2.227-.217.562-.477.96-.896 1.382-.42.419-.819.679-1.381.896-.422.164-1.057.354-2.227.408-1.264.061-1.646.07-4.849.07s-3.585-.009-4.849-.07c-1.171-.054-1.805-.244-2.227-.408-.562-.217-.96-.477-1.382-.896-.419-.42-.679-.819-.896-1.381-.164-.422-.354-1.057-.408-2.227-.061-1.264-.07-1.646-.07-4.849s.009-3.585.07-4.849c.054-1.171.244-1.805.408-2.227.217-.562.477-.96.896-1.382.42-.419.819-.679 1.381-.896.422-.164 1.057-.354 2.227-.408 1.264-.061 1.646-.07 4.849-.07z"/>
                <circle cx="12" cy="12" r="3.846"/>
              </svg>
            </a>
            <a href="https://wa.me/573102861378?text=Hola%20F%C3%A1brica%20de%20Arepas%20Ruiz%2C%20me%20gustar%C3%ADa%20conocer%20m%C3%A1s%20sobre%20sus%20arepas" target="_blank" rel="noopener noreferrer" className="social-icon" aria-label="WhatsApp: +57 310 2861378" title="WhatsApp: +57 310 2861378">
              <svg viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.869 1.171c-1.493.821-2.771 1.98-3.7 3.402C2.508 10.236 2 11.519 2 12.85c0 1.933.582 3.776 1.68 5.389L2.257 22l5.883-1.494c1.502.823 3.185 1.254 4.912 1.254 5.514 0 10-4.486 10-10s-4.486-10-10-10z"/>
              </svg>
            </a>
          </div>
        </div>
      </nav>

      {/* Navigation Menu */}
      <div className="nav-menu">
        <a href="#quienes-somos" onClick={(e) => handleNavClick(e, 'quienes-somos')}>¿Quiénes somos?</a>
        <a href="#catalogo" onClick={(e) => handleNavClick(e, 'catalogo')}>Catálogo</a>
        <a href="#blogs" onClick={(e) => handleNavClick(e, 'blogs')}>Blogs</a>
        <a href="#que-puedes" onClick={(e) => handleNavClick(e, 'que-puedes')}>¿Qué puedes hacer tú?</a>
        <a href="#contactos" onClick={(e) => handleNavClick(e, 'contactos')}>Contactos</a>
      </div>

      {/* Banner Slider */}
      <section className="banner-slider">
        <div className="slider-container">
          <button className="slider-button prev" onClick={prevSlide}>‹</button>
          
          <div className="slider-content">
            <div className="slider-image">
              <img 
                src={banners[currentSlide].image} 
                alt={banners[currentSlide].title}
              />
            </div>
            <div className="slider-text">
              <h2>{banners[currentSlide].title}</h2>
              <p>{banners[currentSlide].description}</p>
            </div>
          </div>

          <button className="slider-button next" onClick={nextSlide}>›</button>
        </div>

        <div className="slider-dots">
          {banners.map((_, index) => (
            <button
              key={index}
              className={`dot ${index === currentSlide ? 'active' : ''}`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      {/* Nuestro Mundo Section */}
      <section className="section-title" id="catalogo">
        <h2>Nuestro Mundo</h2>
      </section>

      {/* Hero Images */}
      <section className="hero-images">
        <div className="hero-card">
          <div className="hero-image">
            <img 
              src="/manus-storage/arepa-queso_ad102b65.png" 
              alt="Arepa rellena de queso"
            />
          </div>
          <div className="hero-text">
            <h3>Arepa rellena de queso</h3>
            <p>Arepa con un queso cremoso que se estira en cada mordida y que te antoja con su olor.</p>
            <button className="btn-conocer" onClick={() => { setSelectedProduct(0); setActiveModal('product-0'); }}>Conocer más</button>
          </div>
        </div>

        <div className="hero-card">
          <div className="hero-image">
            <img 
              src="/manus-storage/arepa-queso-bocadillo_473849da.png" 
              alt="Arepa rellena de queso y bocadillo"
            />
          </div>
          <div className="hero-text">
            <h3>Arepa rellena de queso y bocadillo</h3>
            <p>Una arepa con un queso cremoso y un bocadillo delicioso que le da un toque dulce a la receta.</p>
            <button className="btn-conocer" onClick={() => { setSelectedProduct(1); setActiveModal('product-1'); }}>Conocer más</button>
          </div>
        </div>
      </section>

      {/* Video Slider Section */}
      <section className="section-title" id="que-puedes">
        <h2>Un mundo para imaginar</h2>
      </section>

      <section className="video-slider">
        <button className="slider-button prev" onClick={prevVideoSlide}>‹</button>

        <div className="video-slide-container">
          {currentVideoSlide === 0 ? (
            <>
              <div className="video-placeholder">
                <div className="play-icon">▶</div>
                <p>Proceso de Elaboración de Arepas</p>
              </div>
              <div className="video-text">
                <h3>Cómo se hacen nuestras arepas</h3>
                <p>Mira paso a paso el proceso artesanal de elaboración de nuestras deliciosas arepas. Desde la preparación de la masa hasta el punto perfecto de cocción, conoce el amor que ponemos en cada una.</p>
                <button className="btn-saber" onClick={() => setActiveModal('video-proceso')}>Saber más</button>
              </div>
            </>
          ) : (
            <>
              <div className="video-placeholder">
                <div className="play-icon">▶</div>
                <p>Variedad de Arepas</p>
              </div>
              <div className="video-text">
                <h3>Descubre nuestra variedad</h3>
                <p>Explora los diferentes tipos de arepas que preparamos. Desde las clásicas hasta las más innovadoras, cada una tiene su propio sabor y encanto especial.</p>
                <button className="btn-saber" onClick={() => setActiveModal('video-variedad')}>Saber más</button>
              </div>
            </>
          )}
        </div>

        <button className="slider-button next" onClick={nextVideoSlide}>›</button>
      </section>

      {/* Juega con tu Imaginación */}
      <section className="section-title" id="juega-con-imaginacion">
        <h2>Juega con tu Imaginación</h2>
      </section>

      {/* Product Gallery */}
      <section className="product-gallery" id="producto-gallery">
        {products.map((product, index) => (
          <a key={index} href={`/product/${index}`} className="product-card" style={{ textDecoration: 'none', color: 'inherit' }}>
            <div className="product-image">
              <img src={product.image} alt={product.name} />
            </div>
            <h4>{product.name}</h4>
            <p>{product.description}</p>
          </a>
        ))}
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <div className="footer-logo" style={{paddingRight: '210px'}}>
            <img 
              src="/manus-storage/logo-fabrica-arepas-ruiz-transparent_c56425a6.png" 
              alt="Fábrica de Arepas Ruiz"
            />
          </div>

          <div className="footer-section">
            <h5>Legal</h5>
            <ul>
              <li><a href="#privacidad" onClick={(e) => { e.preventDefault(); setActiveModal('privacidad'); }}>Política de privacidad</a></li>
              <li><a href="#cookies" onClick={(e) => { e.preventDefault(); setActiveModal('cookies'); }}>Política de cookies</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h5>Términos</h5>
            <ul>
              <li><a href="#terminos" onClick={(e) => { e.preventDefault(); setActiveModal('terminos'); }}>Términos y condiciones</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h5>Empresa</h5>
            <ul>
              <li><a href="#sobre-empresa" onClick={(e) => { e.preventDefault(); setActiveModal('sobre-empresa'); }}>Sobre la Empresa</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h5>Contacto</h5>
            <ul>
              <li><a href="#ubicacion" onClick={(e) => handleNavClick(e, 'ubicacion')}>📍 Bogotá D.C.</a></li>
              <li><a href="tel:+573102861378">📞 +57 310 2861378</a></li>
              <li><a href="mailto:fabricadearepasruiz18@gmail.com">📧 fabricadearepasruiz18@gmail.com</a></li>
            </ul>
          </div>

          <div className="footer-section">
            <h5>Menú</h5>
            <ul>
              <li><a href="#inicio" onClick={(e) => handleNavClick(e, 'home')}>Inicio</a></li>
              <li><a href="#catalogo" onClick={(e) => handleNavClick(e, 'catalogo')}>Catálogo</a></li>
              <li><a href="#blogs" onClick={(e) => handleNavClick(e, 'blogs')}>Blogs</a></li>
              <li><a href="#contactos" onClick={(e) => handleNavClick(e, 'contactos')}>Contactos</a></li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; 2026 Fábrica de Arepas Ruiz. Todos los derechos reservados.</p>
          <p>Creada por Kintsugi Multimedia · 2026</p>
        </div>
      </footer>

      {/* Floating Back-to-Top Button */}
      <button 
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
        className="floating-back-to-top" 
        title="Volver al inicio"
      >
        <svg viewBox="0 0 24 24" fill="white">
          <path d="M7 14l5-5 5 5z"/>
        </svg>
      </button>

      {/* Floating WhatsApp Button */}
      <a href="https://wa.me/573102861378?text=Hola%20F%C3%A1brica%20de%20Arepas%20Ruiz%2C%20me%20gustar%C3%ADa%20conocer%20m%C3%A1s%20sobre%20sus%20arepas" className="floating-whatsapp" target="_blank" rel="noopener noreferrer" title="Contáctanos por WhatsApp">
        <svg viewBox="0 0 24 24" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.67-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.076 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421-7.403h-.004a9.87 9.87 0 00-4.869 1.171c-1.493.821-2.771 1.98-3.7 3.402C2.508 10.236 2 11.519 2 12.85c0 1.933.582 3.776 1.68 5.389L2.257 22l5.883-1.494c1.502.823 3.185 1.254 4.912 1.254 5.514 0 10-4.486 10-10s-4.486-10-10-10z"/>
        </svg>
      </a>

      {/* Modals */}
      <Modal
        isOpen={activeModal === 'quienes-somos'}
        onClose={() => setActiveModal(null)}
        title="¿Quiénes Somos?"
      >
        <h3>Bienvenidos a Fábrica de Arepas Ruiz</h3>
        <p>
          Somos una empresa dedicada a la elaboración de arepas tradicionales, con más de 13 años de experiencia en el mercado.
        </p>
        <h3>Nuestra Misión</h3>
        <p>
          Llevar la autenticidad gastronómica a cada rincón, a cada hogar, manteniendo la calidad, frescura y tradición de disfrutar una buena arepa sin importar la hora del día.
        </p>
        <h3>Nuestros Valores</h3>
        <ul>
          <li><strong>Calidad:</strong> Utilizamos ingredientes frescos de la mejor procedencia.</li>
          <li><strong>Tradición:</strong> Respetamos las recetas ancestrales y brindamos una tradición que te recuerda al hogar.</li>
          <li><strong>Pasión:</strong> Cocinamos con amor en cada arepa.</li>
          <li><strong>Sostenibilidad:</strong> Estamos comprometidos con el medio ambiente y la seguridad de cada cliente.</li>
        </ul>
      </Modal>

      <Modal
        isOpen={activeModal === 'blogs'}
        onClose={() => setActiveModal(null)}
        title="Blogs"
      >
        <h3>Historias de arepas</h3>
        <p>
          Descubre cada historia que corre detrás de cada arepa, recetas tradicionales y consejos de creaciones que puedes elaborar con nuestros productos.
        </p>
        <h3>Artículos recientes</h3>
        <ul>
          <li><strong>La historia de nuestra arepa:</strong> Con nuestras arepas trasládate a un mundo de tradición y amor de la abuela.</li>
          <li><strong>Cómo preparar arepas en casa:</strong> Primero saca nuestras deliciosas arepas de su empaque, prende un sartén a fuego medio, úntalo con un poco de aceite o mantequilla, pon la arepa en el sartén y deja que se dore por lado y lado. Una vez hecha, está lista para degustar o para rellenar a tu gusto.</li>
        </ul>
      </Modal>

      <Modal
        isOpen={activeModal === 'contactos'}
        onClose={() => setActiveModal(null)}
        title="Contactos"
      >
        <h3>Información de Contacto</h3>
        <p>
          <strong>Teléfono:</strong> +57 310 2861378<br />
          <strong>Email:</strong> fabricadearepasruiz18@gmail.com<br />
          <strong>Ubicación:</strong> Bogotá D.C.
        </p>
        <h3>Horarios de Atención</h3>
        <p>
          Lunes a sábado de 6:00 a. m. a 3:00 p. m.
        </p>
        <h3>Redes Sociales</h3>
        <p>
          Síguenos en nuestras redes sociales para promociones especiales y contenido exclusivo.<br />
          <strong>TikTok:</strong> fabrica.de.arepas0<br />
          <strong>Instagram:</strong> arepasruizoficial<br />
          <strong>Facebook:</strong> Fábrica de Arepas Ruiz
        </p>
      </Modal>

      <Modal
        isOpen={activeModal?.startsWith('product-') || false}
        onClose={() => setActiveModal(null)}
        title={selectedProduct !== null ? products[selectedProduct].name : ''}
      >
        {selectedProduct !== null && (
          <>
            <img 
              src={products[selectedProduct].image} 
              alt={products[selectedProduct].name}
              style={{ width: '100%', borderRadius: '8px', marginBottom: '16px' }}
            />
            <h3>Descripción</h3>
            <p>{products[selectedProduct].description}</p>
            <h3>Detalles</h3>
            <p>{products[selectedProduct].details}</p>
          </>
        )}
      </Modal>

      <Modal
        isOpen={activeModal === 'video-proceso'}
        onClose={() => setActiveModal(null)}
        title="Proceso de Elaboración de Arepas"
      >
        <h3>Cómo se hacen nuestras arepas</h3>
        <p>
          En este video podrás ver paso a paso el proceso artesanal de elaboración de nuestras deliciosas arepas, 
          desde la preparación de la masa hasta el punto perfecto de cocción.
        </p>
        <h3>Pasos del Proceso</h3>
        <ul>
          <li><strong>Preparación de la masa:</strong> Mezclamos harina de maíz precocida con agua y sal para obtener una masa homogénea</li>
          <li><strong>Reposo:</strong> Dejamos reposar la masa 5 minutos para que adquiera la consistencia perfecta</li>
          <li><strong>Moldeo:</strong> Formamos las arepas con las manos, dándoles forma ovalada característica</li>
          <li><strong>Cocción:</strong> Cocinamos en plancha caliente hasta que se dore perfectamente por ambos lados</li>
          <li><strong>Relleno:</strong> Abrimos la arepa y rellenamos con los ingredientes seleccionados</li>
        </ul>
        <h3>Tiempo Total</h3>
        <p>El proceso completo toma aproximadamente 15-20 minutos desde el inicio hasta tener la arepa lista para servir.</p>
      </Modal>

      <Modal
        isOpen={activeModal === 'video-variedad'}
        onClose={() => setActiveModal(null)}
        title="Variedad de Arepas"
      >
        <h3>Descubre nuestra variedad</h3>
        <p>
          Contamos con una amplia variedad de arepas para satisfacer todos los gustos. Desde las más tradicionales 
          hasta las más innovadoras, cada una es preparada con ingredientes frescos de la más alta calidad.
        </p>
        <h3>Nuestras Especialidades</h3>
        <ul>
          <li><strong>Arepa de Queso y Carne:</strong> Carne desmenuzada jugosa con queso derretido</li>
          <li><strong>Arepa de Queso y Pollo:</strong> Pollo tierno con queso cremoso</li>
          <li><strong>Arepa de Queso y Huevo:</strong> Perfecta para desayuno, con huevo fresco</li>
          <li><strong>Arepa de Queso y Jamón:</strong> Jamón de calidad premium con queso derretido</li>
          <li><strong>Arepa Dulce:</strong> Queso con salsa de mora y leche condensada</li>
        </ul>
        <h3>Personalización</h3>
        <p>
          Todas nuestras arepas pueden personalizarse según tus preferencias. Contáctanos para conocer opciones 
          especiales y combinaciones únicas.
        </p>
      </Modal>

      <Modal
        isOpen={activeModal === 'terminos'}
        onClose={() => setActiveModal(null)}
        title="Términos y Condiciones"
      >
        <h3>Términos y Condiciones</h3>
        <p>
          Bienvenido a Fábrica de Arepas Ruiz. Al acceder y utilizar nuestro sitio web, aceptas estar sujeto a estos términos y condiciones.
        </p>
        <h3>Uso del Sitio</h3>
        <p>
          Nuestro sitio web está diseñado para proporcionar información sobre nuestros productos y servicios. 
          Aceptas utilizar este sitio solo para propósitos legítimos y de conformidad con todas las leyes aplicables.
        </p>
        <h3>Propiedad Intelectual</h3>
        <p>
          Todo el contenido del sitio, incluyendo textos, imágenes, logos y diseños, está protegido por derechos de autor 
          y es propiedad de Fábrica de Arepas Ruiz o sus proveedores de contenido.
        </p>
        <h3>Limitación de Responsabilidad</h3>
        <p>
          Fábrica de Arepas Ruiz no será responsable por daños indirectos, incidentales, especiales o consecuentes que resulten 
          del uso o la incapacidad de usar nuestro sitio web.
        </p>
        <h3>Cambios en los Términos</h3>
        <p>
          Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios serán efectivos 
          inmediatamente después de su publicación.
        </p>
      </Modal>

      <Modal
        isOpen={activeModal === 'privacidad'}
        onClose={() => setActiveModal(null)}
        title="Política de Privacidad"
      >
        <h3>Política de Privacidad</h3>
        <p>
          En la Fábrica de Arepas Ruiz, respetamos tu privacidad y nos comprometemos a proteger tus datos personales.
        </p>
        <h3>Información que Recopilamos</h3>
        <p>
          Podemos recopilar información personal como tu nombre, correo electrónico, número de teléfono y dirección 
          cuando realizas una compra o te pones en contacto con nosotros.
        </p>
        <h3>Cómo Utilizamos tu Información</h3>
        <ul>
          <li>Para procesar tus pedidos y entregas</li>
          <li>Para enviarte información sobre promociones y nuevos productos</li>
          <li>Para mejorar nuestros servicios</li>
          <li>Para responder a tus consultas</li>
        </ul>
        <h3>Protección de Datos</h3>
        <p>
          Implementamos medidas de seguridad para proteger tu información personal contra acceso no autorizado, 
          alteración, divulgación o destrucción.
        </p>
        <h3>Derechos del Usuario</h3>
        <p>
          Tienes derecho a acceder, corregir o eliminar tus datos personales. Contáctanos para ejercer estos derechos.
        </p>
      </Modal>

      <Modal
        isOpen={activeModal === 'cookies'}
        onClose={() => setActiveModal(null)}
        title="Política de Cookies"
      >
        <h3>Política de Cookies</h3>
        <p>
          Nuestro sitio web utiliza cookies para mejorar tu experiencia de navegación y proporcionar funcionalidades personalizadas.
        </p>
        <h3>¿Qué son las Cookies?</h3>
        <p>
          Las cookies son pequeños archivos de texto que se almacenan en tu dispositivo cuando visitas nuestro sitio. 
          Nos ayudan a recordar tus preferencias y mejorar tu experiencia.
        </p>
        <h3>Tipos de Cookies que Utilizamos</h3>
        <ul>
          <li><strong>Cookies Esenciales:</strong> Necesarias para el funcionamiento del sitio</li>
          <li><strong>Cookies de Rendimiento:</strong> Nos ayudan a entender cómo usas el sitio</li>
          <li><strong>Cookies de Funcionalidad:</strong> Recuerdan tus preferencias</li>
          <li><strong>Cookies de Marketing:</strong> Utilizadas para mostrar anuncios relevantes</li>
        </ul>
        <h3>Control de Cookies</h3>
        <p>
          Puedes controlar y eliminar cookies a través de la configuración de tu navegador. 
          Sin embargo, esto puede afectar la funcionalidad del sitio.
        </p>
      </Modal>

      <Modal
        isOpen={activeModal === 'sobre-empresa'}
        onClose={() => setActiveModal(null)}
        title="Sobre la Empresa"
      >
        <h3>Sobre la Fábrica de Arepas Ruiz</h3>
        <p>
          La Fábrica de Arepas Ruiz es una empresa dedicada a la elaboración y distribución de arepas tradicionales con más de 13 años de experiencia en el mercado.
        </p>
        <h3>Nuestra Historia</h3>
        <p>
          Fundada en 2013, Fábrica de Arepas Ruiz nació de la pasión por preservar la auténtica gastronomía colombiana. Comenzamos como un pequeño negocio familiar y hemos crecido para servir a miles de clientes satisfechos.
        </p>
        <h3>Nuestra Misión</h3>
        <p>
          Llevar la auténtica gastronomía venezolana a cada rincón, manteniendo la calidad, frescura y tradición 
          en cada arepa que preparamos.
        </p>
        <h3>Nuestros Valores</h3>
        <ul>
          <li><strong>Calidad:</strong> Utilizamos ingredientes frescos de la mejor procedencia</li>
          <li><strong>Tradición:</strong> Respetamos las recetas ancestrales venezolanas</li>
          <li><strong>Pasión:</strong> Cocinamos con amor en cada arepa</li>
          <li><strong>Sostenibilidad:</strong> Comprometidos con el medio ambiente</li>
          <li><strong>Servicio:</strong> Excelencia en atención al cliente</li>
        </ul>
        <h3>Nuestro Equipo</h3>
        <p>
          Contamos con un equipo de chefs experimentados y profesionales dedicados que trabajan diariamente 
          para ofrecerte los mejores productos y servicios.
        </p>
      </Modal>

      {/* Hidden sections for scroll targets */}
      <div id="terminos" style={{ height: '1px' }}></div>
      <div id="privacidad" style={{ height: '1px' }}></div>
      <div id="cookies" style={{ height: '1px' }}></div>
      <div id="ubicacion" style={{ height: '1px' }}></div>
      <div id="telefono" style={{ height: '1px' }}></div>
      <div id="correo" style={{ height: '1px' }}></div>
      <div id="home" style={{ height: '1px' }}></div>
    </div>
  );
}
