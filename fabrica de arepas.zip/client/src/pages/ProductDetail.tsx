import { useState } from 'react';
import { useLocation } from 'wouter';
import '../styles/product-detail.css';

export default function ProductDetail() {
  const [location, setLocation] = useLocation();
  const [quantity, setQuantity] = useState(1);
  const [selectedVariation, setSelectedVariation] = useState<string | null>(null);
  const [addedToCart, setAddedToCart] = useState(false);

  // Extract product ID from URL
  const productId = parseInt(location.split('/product/')[1] || '0');

  const products = [
    {
      id: 0,
      image: '/manus-storage/arepa-queso_ad102b65.png',
      name: 'Arepa Rellena de Queso',
      description: 'Arepa con un queso cremoso que se estira en cada mordida y que te antoja con su olor',
      details: 'Nuestra arepa de queso es la más tradicional: hecha a base de maíz peto de alta calidad; con un queso derretido que obtiene una textura perfecta que ofrece una experiencia culinaria incomparable.',
      price: '$5.99',
      ingredients: ['Maíz peto de alta calidad', 'Queso cremoso'],
      variations: ['Con cebolla', 'Con aguacate', 'Con salsa picante', 'Con champiñones'],
      calories: '450 kcal',
      prepTime: '15 minutos'
    },
    {
      id: 1,
      image: '/manus-storage/arepa-queso-bocadillo_473849da.png',
      name: 'Arepa Rellena de Queso y Bocadillo',
      description: 'Una arepa con un queso cremoso y un bocadillo delicioso que le da un toque dulce a la receta',
      details: 'Un bocadillo seleccionado que no es empalagoso mezclado con nuestra deliciosa arepa con queso. Una combinación colombiana que garantiza una ternura en cada bocado y el queso cremoso complementa perfectamente el sabor suave del bocadillo.',
      price: '$5.49',
      ingredients: ['Maíz peto de alta calidad', 'Queso cremoso', 'Bocadillo seleccionado'],
      variations: ['Con piña', 'Con BBQ', 'Con cilantro', 'Con tomate'],
      calories: '420 kcal',
      prepTime: '15 minutos'
    },
    {
      id: 2,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/arepa-queso-huevo-cqEZ3c5Z3D8m9zKmYmxYFN.webp',
      name: 'Arepa Rellena de Queso y Huevo',
      description: 'Huevo fresco con queso derretido, perfecta para el desayuno',
      details: 'Ideal para comenzar el día, esta arepa combina huevo fresco cocinado al punto con queso derretido. Una opción nutritiva y deliciosa para cualquier hora del día.',
      price: '$4.99',
      ingredients: ['Huevo fresco', 'Queso derretido', 'Masa de maíz', 'Sal', 'Aceite vegetal'],
      variations: ['Con jamón', 'Con tocino', 'Con cebolla', 'Con pimentón'],
      calories: '380 kcal',
      prepTime: '10 minutos'
    },
    {
      id: 3,
      image: '/manus-storage/arepa-queso-jamon_e13aae09.png',
      name: 'Arepa Rellena de Queso y Jamón',
      description: 'Jamón de calidad premium con queso derretido',
      details: 'Utilizamos jamón de la más alta calidad, importado especialmente para mantener nuestro estándar de excelencia. Combinado con queso derretido, es una delicia para los paladares más exigentes.',
      price: '$6.49',
      ingredients: ['Jamón premium', 'Queso derretido', 'Masa de maíz', 'Pimienta negra', 'Aceite vegetal'],
      variations: ['Con piña', 'Con mostaza', 'Con champiñones', 'Con queso suizo'],
      calories: '$490 kcal',
      prepTime: '12 minutos'
    },
    {
      id: 4,
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663471618102/3eVmNLPXPhPyiS2mABKk5Z/arepa-mora-leche-8DRSa2PFi4MfsrdQfXeVC2.webp',
      name: 'Arepa de Queso con Mora y Leche',
      description: 'Queso con salsa de mora y leche condensada, un postre delicioso',
      details: 'Nuestra arepa dulce es un postre único que combina queso fresco con una deliciosa salsa de mora casera y leche condensada. Una experiencia dulce y memorable.',
      price: '$5.99',
      ingredients: ['Queso fresco', 'Mora fresca', 'Leche condensada', 'Masa de maíz', 'Azúcar'],
      variations: ['Con fresa', 'Con guanabana', 'Con chocolate', 'Con caramelo'],
      calories: '380 kcal',
      prepTime: '8 minutos'
    }
  ];

  const product = products[productId];

  if (!product) {
    return (
      <div className="product-detail-container">
        <div className="error-message">
          <h2>Producto no encontrado</h2>
          <button onClick={() => setLocation('/')}>Volver al inicio</button>
        </div>
      </div>
    );
  }

  return (
    <div className="product-detail-page">
      {/* Navbar */}
      <nav className="navbar-detail">
        <button className="back-button" onClick={() => setLocation('/')}>
          ← Volver
        </button>
        <h1 className="navbar-title">Fábrica de Arepas Ruiz</h1>
      </nav>

      <div className="product-detail-container">
        {/* Product Image */}
        <div className="product-image-section">
          <div className="product-image-wrapper">
            <img src={product.image} alt={product.name} className="product-image-large" />
          </div>
        </div>

        {/* Product Info */}
        <div className="product-info-section">
          <h1 className="product-title">{product.name}</h1>
          <p className="product-description">{product.details}</p>

          {/* Price and Details */}
          <div className="product-meta">
            <div className="price-box">
              <span className="price-label">Precio:</span>
              <span className="price">{product.price}</span>
            </div>
            <div className="meta-info">
              <div className="meta-item">
                <span className="meta-label">⏱️ Tiempo:</span>
                <span>{product.prepTime}</span>
              </div>
              <div className="meta-item">
                <span className="meta-label">🔥 Calorías:</span>
                <span>{product.calories}</span>
              </div>
            </div>
          </div>

          {/* Quantity Selector */}
          <div className="quantity-selector">
            <label>Cantidad:</label>
            <div className="quantity-controls">
              <button onClick={() => setQuantity(Math.max(1, quantity - 1))}>−</button>
              <input type="number" value={quantity} readOnly />
              <button onClick={() => setQuantity(quantity + 1)}>+</button>
            </div>
          </div>

          {/* Add to Cart Button */}
          <button className="add-to-cart-btn" onClick={() => setAddedToCart(true)}>
            {addedToCart ? `Agregado al carrito (${quantity})` : `Agregar al Carrito (${quantity})`}
          </button>
          {addedToCart && (
            <p className="cart-feedback" role="status">
              {quantity} unidad{quantity === 1 ? '' : 'es'} agregada{quantity === 1 ? '' : 's'}.
            </p>
          )}

          {/* Variations */}
          <div className="variations-section">
            <h3>Personalización Disponible</h3>
            <div className="variations-grid">
              {product.variations.map((variation, index) => (
                <button
                  key={index}
                  className={`variation-btn ${selectedVariation === variation ? 'selected' : ''}`}
                  onClick={() => setSelectedVariation(variation)}
                  aria-pressed={selectedVariation === variation}
                >
                  {variation}
                </button>
              ))}
            </div>
            {selectedVariation && (
              <p className="variation-feedback" role="status">Personalización seleccionada: {selectedVariation}</p>
            )}
          </div>
        </div>
      </div>

      {/* Related Products */}
      <section className="related-products">
        <h2>Otras Arepas que Podrían Gustarte</h2>
        <div className="related-grid">
          {products.map((prod, index) => (
            prod.id !== productId && (
              <div 
                key={index} 
                className="related-card"
                onClick={() => setLocation(`/product/${prod.id}`)}
              >
                <img src={prod.image} alt={prod.name} />
                <h4>{prod.name}</h4>
                <p>{prod.description}</p>
                <span className="related-price">{prod.price}</span>
              </div>
            )
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="footer-detail">
        <p>&copy; 2026 Fábrica de Arepas Ruiz. Todos los derechos reservados.</p>
      </footer>
    </div>
  );
}
